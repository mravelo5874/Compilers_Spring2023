name: Marco Ravelo
course: CS 380C Advanced Topics in Compiters
proj: Assignment 4 - Loop Analysis

Status of Submission:
All parts of the assignment are complete. I have included a few test cases that I wrote.

Materials Used:
 - https://llvm.org/docs/GettingStarted.html
 - https://llvm.org/docs/WritingAnLLVMPass.html
 - https://llvm.org/docs/Atomics.html
 - https://www.inf.ed.ac.uk/teaching/courses/ct/17-18/slides/llvm-2-writing_pass.pdf
 - https://secdev.ieee.org/wp-content/uploads/2021/10/tutorial-B1-criswell.pdf
 - https://www.cs.cmu.edu/afs/cs/academic/class/15745-s15/public/lectures/L6-LLVM2-1up.pdf

Feedback:
I would say that this was the most difficult assignment in this course so far. Getting LLVM
setup took up a lot of time. Additionally, having the due date for this assignmnet be only a
few days after the midterm was challenging; I spent most of my time before the exam studying.
I would also like to mention that I was having internet issues all week starting on Saturday
before the due date on Sunday. My internet issues are still a problem but I was able to change
locations to be able to work on my assignemnts during the week. I have already sent you an 
email as I'm sure you are aware. I would greatly appreciate it if no lateness reductions were
done to my grade as these circumstances were out of my control. Thank you again for your
understanding. 

Partner:
I did not have a partner for this assignment. All code was written by me.
